var a = {
  "db_version_time": "20170601010000",
  "response": {
    "count": 1,
    "total_pages": 1,
    "display_range_from": 1,
    "display_range_to": 1,
    "hotel_list": [{
      "maj_mat_cd": "02",
      "region_cd": "007",
      "area_cd": "035",
      "maj_mat_nam": "北海道",
      "region_nam": "札幌・定山渓",
      "area_nam": "札幌（札幌駅周辺）",
      "copt_cd": "10001",
      "facl_cd": "00",
      "dp_supplier_flg": "0",
      "facl_nam": "標準：札幌全日空ホテル",
      "facl_images": null,
      "zip_cd": "060-8615",
      "adrs": "北海道札幌市中央区南2条西12丁目",
      "access": {
        "nearest_sta": [{
          "tm_required": 1,
          "nearest_sta_nam": "札幌駅",
          "walk_car_shp_cf": "0",
          "nearest_route_nam": "札幌本線",
          "nearest_sta_trans": "ＪＲ北海道"
        }, {
          "tm_required": 12,
          "nearest_sta_nam": "函館",
          "walk_car_shp_cf": "0",
          "nearest_route_nam": "函館線",
          "nearest_sta_trans": "ＪＲ北海道"
        }],
        "nearest_airp": [{
          "airp_cd": "CTS",
          "arr_point": "空港入り口",
          "other_nam": null,
          "nearest_airp_note": "高速道路はETCが便利です。",
          "car_tra_bus_shp_cf": "2",
          "ctbs_max_tm_required": 70,
          "ctbs_min_tm_required": 60,
          "ctbs_special_mention": "高速道路利用",
          "ctbs_sm_max_tm_required": 50,
          "ctbs_sm_min_tm_required": 40
        }, {
          "airp_cd": "AKJ",
          "arr_point": "インターチェンジ",
          "other_nam": null,
          "nearest_airp_note": "電車が便利です",
          "car_tra_bus_shp_cf": "1",
          "ctbs_max_tm_required": 40,
          "ctbs_min_tm_required": 30,
          "ctbs_special_mention": "特急利用",
          "ctbs_sm_max_tm_required": 30,
          "ctbs_sm_min_tm_required": 20
        }]
      },
      "tripadvisor": {
        "url": null,
        "rate": null,
        "count": null,
        "image_url": null
      },
      "latitude": null,
      "longitude": null,
      "plan_list": [{
        "day_list": [{
          "cart_key_tour_hotel": "00:00:A670A18E41:10001:00:S00400:#019:001:003:10000140:20171001:1",
          "itin_hndl_no": "10000140",
          "folder_no": "003",
          "upgrade_cf": null,
          "upgrade_no": null
        }],
        "stock": 20,
        "plan_cd": "S00400",
        "num_p_to": 3,
        "plan_nam": "標準：全日空ホテルパッケージ宿専Ｃプラン",
        "product_cd": "00",
        "for_rsv_nam": "標準07-3：禁煙・喫煙指定なし　洋室　シングル",
        "roomtype_cd": "04",
        "lay_side_flg": "0",
        "roomtype_nam": "洋室（シングル）",
        "max_room_area": "30  ",
        "min_room_area": "10  ",
        "room_unit_flg": "0",
        "use_pre_req_no": "001",
        "meal_conditions": [{
          "meal_pre_req_no": "0",
          "meal_pre_requis_nam": "朝食"
        }, {
          "meal_pre_req_no": "1",
          "meal_pre_requis_nam": "夕食"
        }],
        "stock_limits_no": "#019",
        "use_pre_req_dtl": "３名／１室",
        "use_pre_req_nam": "３名／１室",
        "stock_limits_nam": "標準07-3：禁煙・喫煙指定なし　洋室　（３名）　シングル",
        "use_pre_req_unit": "1",
        "kids_lay_side_flg": "0",
        "disp_use_req_unit_nam": "室",
        "add_selling_price_list": {
          "adult": 0,
          "child_a": 0,
          "child_b": 0
        },
        "adult_kind_type_cd": "001",
        "child_a_kind_type_cd": "100",
        "child_b_kind_type_cd": "120",
        "child_a_lying_kind_type_cd": "103",
        "child_b_lying_kind_type_cd": "123"
      }, {
        "day_list": [{
          "cart_key_tour_hotel": "00:00:A670A18E41:10001:00:S00400:#020:001:003:10000140:20171001:1",
          "itin_hndl_no": "10000140",
          "folder_no": "003",
          "upgrade_cf": null,
          "upgrade_no": null
        }],
        "stock": 20,
        "plan_cd": "S00400",
        "num_p_to": 4,
        "plan_nam": "標準：全日空ホテルパッケージ宿専Ｃプラン",
        "product_cd": "00",
        "for_rsv_nam": "標準07-4：禁煙・喫煙指定なし　洋室　セミダブル",
        "roomtype_cd": "10",
        "lay_side_flg": "0",
        "roomtype_nam": "洋室（セミダブル）",
        "max_room_area": "30  ",
        "min_room_area": "10  ",
        "room_unit_flg": "0",
        "use_pre_req_no": "001",
        "meal_conditions": [{
          "meal_pre_req_no": "0",
          "meal_pre_requis_nam": "朝食"
        }, {
          "meal_pre_req_no": "1",
          "meal_pre_requis_nam": "夕食"
        }],
        "stock_limits_no": "#020",
        "use_pre_req_dtl": "４名／１室",
        "use_pre_req_nam": "４名／１室",
        "stock_limits_nam": "標準07-4：禁煙・喫煙指定なし　洋室　（４名）　セミダブル",
        "use_pre_req_unit": "1",
        "kids_lay_side_flg": "0",
        "disp_use_req_unit_nam": "室",
        "add_selling_price_list": {
          "adult": 0,
          "child_a": 0,
          "child_b": 0
        },
        "adult_kind_type_cd": "001",
        "child_a_kind_type_cd": "100",
        "child_b_kind_type_cd": "120",
        "child_a_lying_kind_type_cd": "103",
        "child_b_lying_kind_type_cd": "123"
      }, {
        "day_list": [{
          "cart_key_tour_hotel": "00:00:A670A18E41:10001:00:S00400:#017:001:003:10000140:20171001:1",
          "itin_hndl_no": "10000140",
          "folder_no": "003",
          "upgrade_cf": "H",
          "upgrade_no": "02001"
        }],
        "stock": 20,
        "plan_cd": "S00400",
        "num_p_to": 1,
        "plan_nam": "標準：全日空ホテルパッケージ宿専Ｃプラン",
        "product_cd": "00",
        "for_rsv_nam": "標準07-1：禁煙・喫煙指定なし　洋室　セミダブル　シャワーブースのみ",
        "roomtype_cd": "10",
        "lay_side_flg": "0",
        "roomtype_nam": "洋室（セミダブル）",
        "max_room_area": "20  ",
        "min_room_area": "10  ",
        "room_unit_flg": "1",
        "use_pre_req_no": "001",
        "meal_conditions": [{
          "meal_pre_req_no": "0",
          "meal_pre_requis_nam": "朝食"
        }, {
          "meal_pre_req_no": "1",
          "meal_pre_requis_nam": "夕食"
        }],
        "stock_limits_no": "#017",
        "use_pre_req_dtl": "１名／１室",
        "use_pre_req_nam": "１名／１室",
        "stock_limits_nam": "標準07-1：禁煙・喫煙指定なし　洋室　（１名）　セミダブル　シャワーブースのみ",
        "use_pre_req_unit": "1",
        "kids_lay_side_flg": "0",
        "disp_use_req_unit_nam": "室",
        "add_selling_price_list": {
          "adult": 6325,
          "child_a": 0,
          "child_b": 0
        },
        "adult_kind_type_cd": "001",
        "child_a_kind_type_cd": "100",
        "child_b_kind_type_cd": "120",
        "child_a_lying_kind_type_cd": "103",
        "child_b_lying_kind_type_cd": "123"
      }]
    }]
  }
}
